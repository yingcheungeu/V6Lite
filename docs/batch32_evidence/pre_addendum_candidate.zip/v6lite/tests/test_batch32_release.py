"""The success card is specific only after the existing flat release proof."""
from v6lite.tests.test_batch16_f6_release import _protected_position_flattened_in_tws,_request_release
from v6lite.models import Side

def test_B32_release_title_names_frozen_symbol_and_verified_zero_shares(tmp_path,record_property):
    rig,pid,ref,exec_id=_protected_position_flattened_in_tws(tmp_path)
    _request_release(rig)
    assert not [title for title,body in rig.channel.messages if '已解除冻结' in title]
    assert rig.store.control('frozen:AAPL') is not None
    rig.broker.confirm_cancel(ref);rig.engine._drain(rig.clock.now())
    before=tuple(req.intent_id for req in rig.broker.sent if req.side is Side.SELL)
    _request_release(rig)
    assert rig.store.position(pid)['status']=='RELEASED' and rig.store.control('frozen:AAPL') is None
    [(title,body)]=[(title,body) for title,body in rig.channel.messages if '已解除冻结' in title]
    assert title=='✅ 已解除冻结 · AAPL · 持仓 0 股'
    assert '运行状态有新变化' not in body and 'John' not in body
    assert ref not in rig.broker.cancels and tuple(req.intent_id for req in rig.broker.sent if req.side is Side.SELL)==before
    record_property('b32_release_card_title',title)
    record_property('b32_release_card_body',body)
