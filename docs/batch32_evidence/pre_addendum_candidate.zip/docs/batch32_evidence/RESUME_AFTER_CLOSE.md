# Batch32 收盘后续办

当前候选冻结，未提交/tag。最终聚焦 focused_matrix_1：467 passed，source_unchanged=True；本批新测试31例。原始b31反例red_b31_exact_tape先失败，未修改基线生产代码。

- dev/b31基线：4456af6d1e70be1daa32d5d7870f34d422373383。
- 原指令sha256：b22c24d2ab99765b4332446df20b781ea300eb90b37cb7ad588575daa8ca4c64。
- code_sha：5bcb047fb58259d0。
- package SHA256：5bcb047fb58259d0af634a6e16f6237b9e6bcac26f3707332cb398867025be95。
- inventory SHA256：19c19a1f96dc9ba46fba1d78a5711ab192cb4047b905c89b48bb1963f4e2ae3a。
- 208源码文件；199个Python源码compile/UTF8 AST/无BOM；预期完整2296例（b31 2265+新31）。

先读报告 docs/V6_LITE_FIX_REPORT_ROUND32_2026-10-29.md、原指令、freeze.json、artifact_ownership.json和本文件。严格核对冻结的源码/工具/SDK/OWNED文档（尤其opening proposal）及只读输入。docs/batch32_claude_evidence/只读，manifest SHA256 9e56247d3a27aee3544065669e08257b1be623c9ceea916d0bb94fbb68412b7c，3文件；不改、不纳入allowlist。使用v6lite_b32_inputs.py复核。原生回放、报告限定和两项只读复核见read_only_review.json。

修复重点：raw hook独立快照在过滤/投影前统一归并完全相同自有行；SDK可变Trade别名缺原始标记不归并；任何矛盾整轮拒绝，不返回部分结果或发ACK；真实矛盾冻结/P1/P0、STP不写；duplicate只审计、不撤销continuation；原始坏数量（包括单条）不能回退为0；S/自有T来自同一规范化结果；release具体成功卡片。10/29三条相同记录可确认，三次回调各自业务来源/间隔不确定；10/27同因仍推断，不能补造原始字段。

开盘30秒仅调查/方案，文件 docs/V6_LITE_BATCH32_OPEN_TP_PROPOSAL_2026-10-29.md，待Claude裁定，本批绝不实施。config/exits/market_calendar/protection_engine及退出决策方法均与b31一致。既有real_failure冻结不回写或自动迁移。

## 三次串行Windows全量

用真实PT时钟确认 >= 2026-10-29 13:30 且不在任何交易日06:00–13:30。激活 C:\Dev\V6Lite-dev\.venv，设置 PYTHONUTF8=1、PYTHONIOENCODING=utf-8。先确认没有其他验证进程/锁，严禁并行或盲删锁。只串行：

```powershell
python -B docs/batch32_evidence/v6lite_b32_validate.py release_full_1 full
python -B docs/batch32_evidence/v6lite_b32_validate.py release_full_2 full
python -B docs/batch32_evidence/v6lite_b32_validate.py release_full_3 full
```

每次等完成，核验rc/failures/errors=0、完整XML2296例、同一code_sha/inventory/source_unchanged/read_only_inputs_unchanged、日志XML SHA，再下一次。三次完整case身份及skip身份相同，起止串行；通常b31既有skip为legacy market_scanner.py缺文件，但以实际XML为准，不能新增豁免。

已有产物不得覆盖。失败保留并调查；确定性错误不伪称flake。若需修复源码/工具，先保存当前freeze/报告/工具字节副本，再修复、聚焦/编译/独立审查、重新冻结，随后重启连续三次。第三次同一flake必须修复或直接用户重定义门槛，不能重试掩盖。新增的真实回执与快照须加入artifact_ownership.json，不能隐藏失败或扩大到原始证据目录。

## 收口与本地交付

三次通过后：

```powershell
python -B docs/batch32_evidence/v6lite_b32_closeout.py final release_full_1 release_full_2 release_full_3
python -B docs/batch32_evidence/v6lite_b32_git_deliver.py commit
```

closeout核验freeze/工具/SDK/输入、三次case/skip、无夹入全量失败，生成实际报告/卡片样例/SHA256SUMS/closeout和 C:\tmp\v6lite_b32_stage_paths.json。只允许OWNED源码/指令/proposal/report及artifact_ownership中的自有输出；排除原始证据、baseline_b31、操作手册和其他历史文件。若更换全量label，向final显式传入三者并保留旧失败。

git_deliver按精确allowlist本地dev提交、annotated v6lite-batch32，核验tag归档inventory/package/code_sha、report/manifest所有blob，读取 C:\tmp\v6lite_b32_delivery.json。部分提交/tag存在先核对真实状态，不覆盖tag、不重复提交、不unstage外来文件。报告生成于提交前，实际提交hash由交付回执和最终回复给出，避免修改已核验tag。

不push/merge/部署，不连接TWS/Gateway，不真实下单，不碰用户.v6lite/运行仓库/John配置/操作手册。操作手册已有他人改动保持。全部交付后冻结等待Claude复核并删除本次续办，不再继续源码工作，不向其他聊天/邮件/Discord发消息。
